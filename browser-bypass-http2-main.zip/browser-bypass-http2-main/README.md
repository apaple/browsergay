# How to install ?

1- curl -sL https://deb.nodesource.com/setup_16.x | sudo bash -

2- sudo apt -y install nodejs

3- npm install puppeteer-extra puppeteer-extra-plugin-recaptcha puppeteer-extra-plugin-stealth

4- chmod 777 *

# How to use ?

node golang_engine.js URL proxy.txt 1200 20 GET 64

# Explanation

1200 = attack time

20 = how many open browser

64 = request per ip

Note: 

1- script using 2capcha api as below, you can change it

2- flooder "optls" coded in C# and compiled. it's clean and you can replace it with and flooder support cookie.

            provider: {
                id:'2captcha',
                token:'67dd29dd93bcfe3f5b451451b6d98226'
                
# This script coded by Ch2K1t and hacked/leaked by Mesh3l ...                

![image](https://user-images.githubusercontent.com/65688554/165854327-759e6993-9178-450b-b49a-89cf185ab3ac.png)

![image](https://user-images.githubusercontent.com/65688554/165854549-fd603942-e592-4730-b2c2-33d95925bfcc.png)
